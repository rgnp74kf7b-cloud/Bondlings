Bondlings - Number Bond Battles
Presented by Dyslexia South East CIC

PLAY OFFLINE
Double-click index.html. Modes: vs Robot and Pass & play. No internet needed.

PLAY ONLINE WITH A FRIEND (needs the game on a website)
1. Put index.html on a website (GitHub + Cloudflare Pages works well; see the guide).
2. Open your site, choose "Play online with a friend", set your options, then click
   "Create game & get link".
3. Send the link to your friend. When they open it the game starts automatically.
   You (the host) choose the settings; your friend plays with the same ones.

How it works: the two browsers connect directly to each other (WebRTC). The free PeerJS
service only introduces them, then game messages go straight between the two devices.
Both need an internet connection. Some school or office networks block direct connections;
if the game can't connect, try a different network or a phone hotspot.

SOUND: use the speaker button (top right) to mute.
